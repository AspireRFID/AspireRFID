Fosstrak Filtering and Collection Commons
=======================================

The objective of the Fosstrak Filtering and Collection Commons module is to provide 
common functionality used by the different Filtering and Collection modules.


How to use the Filtering and Collection Commons
===============================================

The module is included in the different Filtering and Collection modules as a dependency.

For more information,  please see http://www.fosstrak.org/fc
